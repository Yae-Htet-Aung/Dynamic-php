<?php
error_reporting(1);
session_start();
$eId = $_REQUEST["eId"];
include("connection.php");

if ($_SESSION['sid'] == "") {
  header('location:sry.html');
} else {
?>

  <!DOCTYPE html>
  <html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>Contact</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!--

TemplateMo 546 my Clothing

https://templatemo.com/tm-546-my-clothing

-->

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="style.css">

    <!-- yae -->
    <link rel="stylesheet" href="style.css">
  </head>

  <body>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
      <div class="jumper">
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php">
            <h2>Traveler<em>Vibe</em></h2>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">

              <?php
              echo "
              <li class='nav-item'>
                <a href='index_reg.php?eId=$eId' class='nav-link'>Home</a>
                <span class='sr-only'>(current)</span>
              </li>

              <li class='nav-item'>
                <a href='packages_reg.php?eId=$eId' class='nav-link'>Packages</a>
                <span class='sr-only'>(current)</span>
              </li>

              <li class='nav-item active'>
                <a href='contact_reg.php?eId=$eId' class='nav-link'>Contact Us</a>
                <span class='sr-only'>(current)</span>
              </li>

              <li class='nav-item'>
                <a href='wish_reg.php?eId=$eId' class='nav-link'>Wish List</a>
                <span class='sr-only'>(current)</span>
              </li>

              <li class='nav-item'>
                <a href='profile.php?eId=$eId' class='nav-link'>Profile</a>
                <span class='sr-only'>(current)</span>
              </li>
              ";
              ?>

              <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
              </li>

            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="banner header-text">
      <img src="pictures/contact_heading.png" style="background-repeat: no-repeat; background-size: cover;" width="100%">
      <div class="text-content">
        <br><br><br>
        <h2>
          <em>
            <font class="myH1">Send us Feedbacks</font>
          </em>
        </h2>
      </div>
    </div>
    <!-- Banner Ends Here -->

    <?php
    error_reporting(1);
    include("connection.php");

    if (isset($_POST['send_btn'])) {
      $name = $_POST['name'];
      $mobile = $_POST['mobile'];
      $email = $_POST['email'];
      $message = $_POST['message'];

      $sql = "INSERT INTO feedback(Name,Mobile,Email,Message) VALUES ('$name','$mobile','$email','$message')";
      if (mysql_query($sql)) {
        $reply = "<font color='teal' size='+1'> Message was sent successfully :) </font>";
      } else {
        $reply = "<font color='red' size='+1'> Message wasn't sent successfully :( </font>";
      }
    }

    $d = mysql_query(" SELECT * FROM registers WHERE Email='{$eId}' ");
    $row = mysql_fetch_object($d);
    $nameAuto = $row->Name;
    $mobAuto = $row->Mobile;

    ?>
    <div class="send-message">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Send us a Feedback Message</h2>
              <?php echo $reply; ?>
            </div>
          </div>
          <div class="col-md-8">
            <div class="contact-form">
              <form id="contact" action="" method="post">
                <div class="row">
                  <div class="col-lg-12 col-md-12 col-sm-12">
                    <?php
                    echo "
                    <fieldset>
                      <input name='name' type='text' class='form-control' id='name' value='$nameAuto' placeholder='Full Name' required=''>
                    </fieldset>
                    ";
                    ?>
                  </div>

                  <div class="col-lg-12 col-md-12 col-sm-12">
                    <?php
                    echo "
                    <fieldset>
                      <input name='mobile' type='text' class='form-control' id='' value='$mobAuto' placeholder='Mobile Number' required=''>
                    </fieldset>
                    ";
                    ?>
                  </div>

                  <div class="col-lg-12 col-md-12 col-sm-12">
                    <?php
                    echo "
                    <fieldset>
                      <input name='email' type='text' class='form-control' id='name' value='$eId' placeholder='E-Mail' required=''>
                    </fieldset>
                    ";
                    ?>
                  </div>

                  <div class="col-lg-12">
                    <fieldset>
                      <textarea name="message" rows="4" class="form-control" placeholder="Your Message" required=""></textarea>
                    </fieldset>
                  </div>
                  <div class="col-lg-12">
                    <fieldset>
                      <button name="send_btn" type="submit" class="filled-button">Send Feedback</button>
                      <!-- <input name="send_btn" type="submit" value="Send Feedback"> -->
                    </fieldset>
                  </div>

                </div>
              </form>
            </div>
          </div>

          <div class="col-md-4">
            <div class="container">

              <div class="row">
                <!-- <div class="com_info"> -->

                <h3>
                  <font color='orange'>Our Company's Contact Information</font>
                </h3>
                <div class="align-items-end">
                  <b><i>TravelerVibe Travel and Tour Co. Ltd,.</i></b>
                  <p>No. 35 Zawna Tower A, Room 2002, Thingangyun Tshp., Yangon, Myanmar. </p>
                  <p>Tel : <a href='#'>+959000000001</a>
                  <p>
                  <p>Email : <a href='#'>TravelerVibe.mm@gmail.com</a></p>
                </div>

                <!-- </div> -->
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>

    
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="inner-content">
              <p>Copyright &copy; 2023 TravelerVibe.com

                - Design: <a rel="nofollow noopener" href="#" target="_blank">Yae Htet Aung</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/accordions.js"></script>


    <script language="text/Javascript">
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t) { //declaring the array outside of the
        if (!cleared[t.id]) { // function makes it static and global
          cleared[t.id] = 1; // you could use true and false, but that's more typing
          t.value = ''; // with more chance of typos
          t.style.color = '#fff';
        }
      }
    </script>


  </body>

  </html>

<?php } ?>