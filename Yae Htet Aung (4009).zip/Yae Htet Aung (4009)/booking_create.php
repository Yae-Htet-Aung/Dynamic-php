<?php
error_reporting(1);
session_start();
include("connection.php");
$eId = $_REQUEST["eId"];
$pId = $_REQUEST["pId"];


if ($_SESSION['sid'] == "") {
  header('location:sry.html');
} else {
?>

  <?php

  $reg = mysql_query("SELECT * FROM registers WHERE Email='{$eId}'");
  $row = mysql_fetch_object($reg);
  $name = $row->Name;
  $mobile = $row->Mobile;
  $address = $row->Address;

  $pkg = mysql_query("SELECT * FROM Packages WHERE ID='{$pId}'");
  $row2 = mysql_fetch_object($pkg);
  $pkgName = $row2->Package;
  $price = $row2->Price;

  // echo "
  //     Name: $name <br>
  //     Email: $eId <br>
  //     Mob: $mobile <br>
      
  //     Package Name: $pkgName <br>
  //     Package ID: $pId <br>
  //     Price: $price <br>";

  
  $insert = "INSERT INTO Bookings (PkgName, PkgID, Price, Name, Mobile, Email, Status) 
  VALUES('$pkgName','$pId','$price', '$name', '$mobile', '$eId', 'Pending')";
  $result = mysql_query($insert) or die("Save items query fail!");
  if ($result) {
    $rp = " Booked successfully :) ";
    header("location: wish_reg.php?rp=$rp&eId=$eId");
  } else {
    $rp = " Booking Failed! :( ";
    header("location: wish_reg.php?rp=$rp&eId=$eId");
  }
  mysql_close($con);

  ?>

<?php } ?>