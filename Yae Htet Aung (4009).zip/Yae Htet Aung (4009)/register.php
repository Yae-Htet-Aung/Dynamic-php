<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

  <title>TravelerVibe.com - Register</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--

TemplateMo 546 my Clothing

https://templatemo.com/tm-546-my-clothing

-->

  <!-- Additional CSS Files -->
  <link rel="stylesheet" href="assets/css/fontawesome.css">
  <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
  <link rel="stylesheet" href="assets/css/owl.css">

  <!-- yae -->
  <link rel="stylesheet" href="style.css" type="text/css">

</head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="preloader">
    <div class="jumper">
      <div></div>
      <div></div>
      <div></div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!-- Header -->
  <header class="">
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <a class="navbar-brand" href="index.php">
          <h2>Traveler<em>Vibe</em></h2>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="packages.php">Packages</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact Us</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="register.php">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php">Login</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>

  <!-- Page Content -->
  <!-- Banner Starts Here -->
  <div class="banner header-text">
    <img src="pictures/register_heading.png" style="background-repeat: no-repeat; background-size: cover;" width="100%">
    <div class="text-content">
      <br><br><br>
      <h2>
        <em>
          <font class="myH1">Registration</font>
        </em>
      </h2>
    </div>
  </div>
  <!-- Banner Ends Here -->


  <?php
  error_reporting(1);
  session_start();
  include("connection.php");

  if (isset($_POST['register_btn'])) {
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $pswd = $_POST['passwd'];
    $add = $_POST['addrs'];

    $sql = "INSERT INTO registers (ID, Name, Mobile, Email, Password, Address) VALUES ('','$name','$mobile','$email','$pswd', '$add')";
    if (mysql_query($sql)) {
      //? IMPORTANT "php?Name=$name & Email=$email"
      $rp = "<font color='darkgreen'> Registration Successful :) </font><br> 
      <font color='slategray'> You can book any packages, now. </font>";
      $_SESSION['sid'] = $email;
      header("location:packages_reg.php?rp=$rp & eId=$email");
    } else {
      $rp = "<font color='red'> Registration Failed :( </font>";
    }
  }

  if (isset($_POST['login_btn'])) {
    header("location:login.php?eId=$email");
  }

  ?>


  <div class="send-message">
    <div class="container">
      <div class="row">

        <div class="col-md-12">

          <div class="col-md-12">
            <div class="section-heading">
              <h2>Register or Login for Booking</h2>
              <h2><?php echo $rp; ?></h2>
            </div>
          </div>
        </div>



        <div class="col-md-5">
          <div class="contact-form">
            <form id="contact" action="" method="post">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                  <fieldset>
                    <input name="name" type="text" class="form-control" id="name" placeholder="Full Name">
                    <!--  required="" -->
                  </fieldset>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                  <fieldset>
                    <input name="mobile" type="text" class="form-control" id="mobile" placeholder="Mobile Number">
                  </fieldset>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                  <fieldset>
                    <input name="email" type="text" class="form-control" id="email" placeholder="E-Mail Address">
                  </fieldset>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                  <fieldset>
                    <input name="passwd" type="password" class="form-control" id="" placeholder="Create your Password">
                  </fieldset>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                  <fieldset>
                    <input name="addrs" type="text" class="form-control" id="" placeholder="Address">
                  </fieldset>
                </div>
              </div>

              <div class="container px-4 text-center">
                <div class="row gx-5">
                  <div class="col">
                    <div class="p-1">
                      <fieldset>
                        <button name="register_btn" type="submit" class="filled-button my_padding">Register Now</button>
                      </fieldset>
                    </div>
                  </div>
                  <div class="col">
                    <div class="p-1">
                      <fieldset>
                        <button name="login_btn" type="submit" class="filled-button my_padding">Login Now</button>
                      </fieldset>
                    </div>
                  </div>
                </div>
              </div>

              <div class="row col-lg-12 justify-content-md-center">
                <div class="col-md-auto">
                  <fieldset>
                    <p class="reg_text">Already Registered?
                      <?php echo '<a href="login.php?pkgID=$pkg_id"> Login Now </a>'; ?>
                    </p>
                  </fieldset>
                </div>
              </div>

            </form>
          </div>
        </div>

        <div class="col-md-7">
          <img src="pictures/register_sub.jpg" width="100%" height="88.5%">
        </div>
        <!-- accordion -->
      </div>
    </div>
  </div>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="inner-content">
            <p>Copyright &copy; 2023 TravelerVibe.com

              - Design: <a rel="nofollow noopener" href="#" target="_blank">Yae Htet Aung</a></p>
          </div>
        </div>
      </div>
    </div>
  </footer>


  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


  <!-- Additional Scripts -->
  <script src="assets/js/custom.js"></script>
  <script src="assets/js/owl.js"></script>
  <script src="assets/js/slick.js"></script>
  <script src="assets/js/isotope.js"></script>
  <script src="assets/js/accordions.js"></script>


  <script language="text/Javascript">
    cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
    function clearField(t) { //declaring the array outside of the
      if (!cleared[t.id]) { // function makes it static and global
        cleared[t.id] = 1; // you could use true and false, but that's more typing
        t.value = ''; // with more chance of typos
        t.style.color = '#fff';
      }
    }
  </script>


</body>

</html>