<?php
session_start();
error_reporting(1);
include("connection.php");

if (isset($_POST['login'])) {
  if ($_POST['email'] == "" || $_POST['pswd'] == "") {
    $err = "Please Fill your Email and Password First!";
  } else {
    $d = mysql_query("SELECT * FROM registers WHERE Email='{$_POST['email']}' ");
    $row = mysql_fetch_object($d);
    $fid = $row->Email;
    $fpass = $row->Password;
    if ($fid == $_POST['email'] && $fpass == $_POST['pswd']) {
      $_SESSION['sid'] = $_POST['email'];
      $rp = "<font color='darkgreen'> Login Successful :) </font><br>
      <font color='slategray'> You can book any packages, now. </font>";
      header("location:packages_reg.php?eId=$fid&rp=$rp");
    } elseif ($fid != $_POST['email']) {
      $err = " Your User Email is Incorrect! ";
    } else {
      $err = " Your Password is Incorrect! ";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

  <title>TravelerVibe.com - Login</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- yae -->
  <link rel="stylesheet" href="style.css" type="text/css">
  <!--

TemplateMo 546 my Clothing

https://templatemo.com/tm-546-my-clothing

-->

  <!-- Additional CSS Files -->
  <link rel="stylesheet" href="assets/css/fontawesome.css">
  <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
  <link rel="stylesheet" href="assets/css/owl.css">

</head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="preloader">
    <div class="jumper">
      <div></div>
      <div></div>
      <div></div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!-- Header -->
  <header class="">
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <a class="navbar-brand" href="index.php">
          <h2>Traveler<em>Vibe</em></h2>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="packages.php">Packages</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="register.php">Register</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="login.php">Login</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>

  <!-- Page Content -->
  <!-- Banner Starts Here -->
  <div class="banner header-text">
    <img src="pictures/login_heading.png" style="background-repeat: no-repeat; background-size: cover;" width="100%">
    <div class="text-content">
      <br><br><br>
      <h2>
        <em>
          <font class="myH1">User Login</font>
        </em>
      </h2>
    </div>
  </div>
  <!-- Banner Ends Here -->


  <div class="send-message">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="section-heading">
            <h4>Login for Booking</h4><br>

            <h6>
              <font color='red'><?php echo $err; ?></font>
            </h6>
          </div>
        </div>

        <div class="col-md-5">
          <div class="contact-form">
            <form id="contact" action="" method="post">
              <div class="row">

                <div class="col-lg-12 col-md-12 col-sm-12">
                  <fieldset>
                    <input name="email" type="text" class="form-control" id="" placeholder="E-Mail Address" required="">
                  </fieldset>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                  <fieldset>
                    <input name="pswd" type="password" class="form-control" id="" placeholder="Password" required="">
                  </fieldset>
                </div>


                <div class="col-lg-12">
                  <fieldset>
                    <button name="login" type="submit" class="filled-button">Login</button>
                    <!-- <input name="register_btn" type="submit" value="Register Now"> -->
                  </fieldset>
                </div>
              </div>
            </form>
          </div>
        </div>
        
        <div class="col-md-7">
          <img src="pictures/login_sub.jpg" width="100%" height="44.5%">
        </div>
        
      </div>
    </div>
  </div>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="inner-content">
            <p>Copyright &copy; 2023 TravelerVibe.com

              - Design: <a rel="nofollow noopener" href="#" target="_blank">Yae Htet Aung</a></p>
          </div>
        </div>
      </div>
    </div>
  </footer>


  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


  <!-- Additional Scripts -->
  <script src="assets/js/custom.js"></script>
  <script src="assets/js/owl.js"></script>
  <script src="assets/js/slick.js"></script>
  <script src="assets/js/isotope.js"></script>
  <script src="assets/js/accordions.js"></script>


  <script language="text/Javascript">
    cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
    function clearField(t) { //declaring the array outside of the
      if (!cleared[t.id]) { // function makes it static and global
        cleared[t.id] = 1; // you could use true and false, but that's more typing
        t.value = ''; // with more chance of typos
        t.style.color = '#fff';
      }
    }
  </script>


</body>

</html>