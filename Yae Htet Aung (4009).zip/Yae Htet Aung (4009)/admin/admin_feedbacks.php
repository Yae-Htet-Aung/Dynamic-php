<?php
session_start();
if ($_SESSION['sid'] == "") {
    header('location:../sry.html');
} else {
?>

    <!DOCTYPE html>
    <html lang="en">

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

        <title>my Clothing HTML Template</title>

        <!-- Bootstrap core CSS -->
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <link href="../style.css" rel="stylesheet">
        <!--

TemplateMo 546 Sixteen Clothing

https://templatemo.com/tm-546-sixteen-clothing

-->

        <!-- Additional CSS Files -->
        <link rel="stylesheet" href="assets/css/fontawesome.css">
        <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
        <link rel="stylesheet" href="assets/css/owl.css">

    </head>

    <body>

        <!-- ***** Preloader Start ***** -->
        <div id="preloader">
            <div class="jumper">
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
        <!-- ***** Preloader End ***** -->

        <!-- Header -->
        <header class="">
            <nav class="navbar navbar-expand-lg">
                <div class="container">
                    <a class="navbar-brand" href="index.php">
                        <h2>traveler<em>vibe</em></h2>
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarResponsive">
                        <ul class="navbar-nav ml-auto">
                            <?php
                            echo "
                            <li class='nav-item'>
                                <a class='nav-link' href='home.php'>Home
                                <span class='sr-only'>(current)</span>
                                </a>
                            </li>
                            <li class='nav-item'>
                                <a class='nav-link' href='add_package.php'>Add Package
                                <span class='sr-only'>(current)</span>
                                </a>
                            </li>
                            <li class='nav-item'>
                                <a class='nav-link' href='admin_packages.php'>Packages</a>
                            </li>
                            <li class='nav-item'>
                                <a class='nav-link' href='bookings.php'>Bookings</a>
                            </li>
                            <li class='nav-item active'>
                                <a class='nav-link' href='admin_feedbacks.php'>Feedbacks</a>
                            </li>";

                            ?>
                            <li class="nav-item">
                                <a class="nav-link" href="logout.php">Log Out</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </header>

        <!-- Page Content -->
        <!-- Banner Starts Here -->
        <div class="banner header-text">
            <img src="../pictures/admin_heading.png" style="background-repeat: no-repeat; background-size: cover;" width="100%">
            <div class="text-content">
                <h2>
                    <em>
                        <br>
                        <font class="myH1">Feedbacks</font>
                    </em>
                </h2>
            </div>
        </div>
        <!-- Banner Ends Here -->


        <?php
        error_reporting(1);
        include("connection.php");

        $preCheck = mysql_query("SELECT * FROM feedback");
        while ($row = mysql_fetch_object($preCheck)) {
            $anyMsg = $row->Message;
            // echo "pre= $pre<br>";
            if (empty($anyMsg)) {
                echo "anyMessage >> " . $anyMsg;
                break;
            }
        }

        if ($anyMsg == "") {
            echo "
          <div class='send-message'>
            <div class='container'>
                <div class='row'>
                    <div class='col-md-12'>
                        <div class='section-heading'>
                          <center>
                            <h2>Nothing to show :( </h2>
                          </center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
          ";
        } else {
            echo "

    
      <div class='send-message col-md-12'>
        <table class='table'>
            <tr class='table-info'>
                <td class='col-md-2'>
                <h5>Name</h5>
                </td>

                <td class='col-md-2'>
                <h5>Gmail</h5>
                </td>

                <td class='col-md-2'>
                <h5>Mobile No.</h5>
                </td>

                <td class='col-md-5'>
                    <h5>Message</h5>
                </td>

                <td class='col-md-1'>
                    
                </td>
            </tr>
        ";

            $sel = mysql_query("SELECT * FROM feedback");
            while ($arr = mysql_fetch_array($sel)) {
                $name = $arr['Name'];
                $mob = $arr['Mobile'];
                $email = $arr['Email'];
                $msg = $arr['Message'];

                echo "

            <tr class='table-secondary'>
                <td class='col-md-2'>
                <h6>$name</h6>
                </td>

                <td class='col-md-2'>
                <h6>$email</h6>

                </td>
                <td class='col-md-2'>
                <h6>$mob</h6>

                </td>
                <td class='col-md-5'>
                <h6>$msg</h6>
                </td>

                <td class='col-md-1'>
                    <fieldset>
                          <a href='feedback_delete.php?eId=$email' type='button' class='btn btn-outline-danger'> Delete </a>
                    </fieldset>
                </td>
            </tr>
                        ";
            }
            echo "</table>
        </div>";
        }
        ?>

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="inner-content">
                            <p>Copyright &copy; 2023 TravelerVibe.com

                                - Design: <a rel="nofollow noopener" href="#" target="_blank">Yae Htet Aung</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>




        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


        <!-- Additional Scripts -->
        <script src="assets/js/custom.js"></script>
        <script src="assets/js/owl.js"></script>
        <script src="assets/js/slick.js"></script>
        <script src="assets/js/isotope.js"></script>
        <script src="assets/js/accordions.js"></script>


        <script language="text/Javascript">
            cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
            function clearField(t) { //declaring the array outside of the
                if (!cleared[t.id]) { // function makes it static and global
                    cleared[t.id] = 1; // you could use true and false, but that's more typing
                    t.value = ''; // with more chance of typos
                    t.style.color = '#fff';
                }
            }
        </script>


    </body>

    </html>

<?php }  ?>