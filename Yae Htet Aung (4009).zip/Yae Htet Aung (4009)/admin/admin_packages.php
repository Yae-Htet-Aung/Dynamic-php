<?php
session_start();
error_reporting(1);
$rp = $_REQUEST['rp'];
if ($_SESSION['sid'] == "") {
  header('location:../sry.html');
} else {
?>

  <!DOCTYPE html>
  <html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>mySummer Packages</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <link href="../style.css" rel="stylesheet">
    <!--

TemplateMo 546 Sixteen Clothing

https://templatemo.com/tm-546-sixteen-clothing

-->

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
    <link rel="stylesheet" href="assets/css/owl.css">

  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
      <div class="jumper">
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php">
            <h2>traveler<em>vibe</em></h2>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <?php
              echo "
              <li class='nav-item'>
                  <a class='nav-link' href='home.php'>Home
                  <span class='sr-only'>(current)</span>
                  </a>
              </li>
              <li class='nav-item'>
                <a class='nav-link' href='add_package.php'>Add Package
                  <span class='sr-only'>(current)</span>
                </a>
              </li>
              <li class='nav-item active'>
                <a class='nav-link' href='admin_packages.php'>Packages</a>
              </li>
              <li class='nav-item'>
                <a class='nav-link' href='bookings.php'>Bookings</a>
              </li>
              <li class='nav-item'>
                <a class='nav-link' href='admin_feedbacks.php'>Feedbacks</a>
              </li>
              <li class='nav-item'>
                <a class='nav-link' href='logout.php'>Log Out</a>
              </li>";

              ?>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="banner header-text">
      <img src="../pictures/admin_heading.png" style="background-repeat: no-repeat; background-size: cover;" width="100%">
      <div class="text-content">
        <h2>
          <em>
            <br>
            <font class="myH1">Uploaded Packages</font>
          </em>
        </h2>
      </div>
    </div>
    <!-- Banner Ends Here -->


    <div class="send-message mb-3 mt-5">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading mb-0 mt-0">
              <?php echo $rp; ?>
            </div>
          </div>
        </div>
      </div>
    </div>


    <div class="products mt-0">
      <div class="container">
        <div class="row">

          <?php
          error_reporting(1);
          include("connection.php");
          $sel = mysql_query("select * from packages ");
          echo "<div class='thumb-container'>
        <div class='container'>
          <div class='row'>";

          $n = 0;
          while ($arr = mysql_fetch_array($sel)) {
            $pic = $arr['Picture'];
            $pkg_name = $arr['Package'];
            $info = $arr['Info'];
            $id = $arr['ID'];
            $price = $arr['Price'];

            echo "
<div class='col-md-4'>
  <div class=''>
  
    <div class='product-item'>
      <div class='down-content'>
        <a href='#'><img src='image/$pic' height='150' width='200'></a>
      </div>

      <div class='down-content'>
        
        <h4><a href='#'><b>$pkg_name</b></a></h4>
        
        <h4>ID: $id</h4>
        
        <p align='justify'> $info </p>

        <h4 align='right'><font color='black'> &dollar;$price </font></h4>

        <div class='container px-2 text-center'>
          <div class='row gx-3'>
            <div class='col'>
              <div class='p-1'>
                <a href='pkg_edit.php?id=$id&pic=$pic' class='btn btn-outline-info'>
                  &nbsp;&nbsp; Edit &nbsp;&nbsp;
                </a>
              </div>
            </div>
            <div class='col'>
              <div class='p-1'>
                <a href='pkg_delete.php?id=$id&pic=$pic' class='btn btn-outline-danger'>Delete</a>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
    
  </div>
</div>";

            $n++;
          }
          echo "</div></div></div>";
          ?>

        </div>
      </div>
    </div>


    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="inner-content">
              <p>Copyright &copy; 2023 TravelerVibe.com

                - Design: <a rel="nofollow noopener" href="#" target="_blank">Yae Htet Aung</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>

  <?php }  ?>
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


  <!-- Additional Scripts -->
  <script src="assets/js/custom.js"></script>
  <script src="assets/js/owl.js"></script>
  <script src="assets/js/slick.js"></script>
  <script src="assets/js/isotope.js"></script>
  <script src="assets/js/accordions.js"></script>


  <script language="text/Javascript">
    cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
    function clearField(t) { //declaring the array outside of the
      if (!cleared[t.id]) { // function makes it static and global
        cleared[t.id] = 1; // you could use true and false, but that's more typing
        t.value = ''; // with more chance of typos
        t.style.color = '#fff';
      }
    }
  </script>


  </body>

  </html>