<?php
error_reporting(1);
$id = $_REQUEST['id'];
$pic = $_REQUEST['pic'];
session_start();

include("connection.php");

if ($_SESSION['sid'] == "") {
  header('location:../sry.html');
} else {
?>

  <?php
  $sql = mysql_query("DELETE FROM packages WHERE id='{$id}'");
  unlink("image/" . $pic);
  rmdir("image/" . $pic);
  header('location:admin_packages.php');
  ?>

<?php } ?>