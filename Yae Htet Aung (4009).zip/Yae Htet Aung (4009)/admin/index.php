<?php
session_start();
error_reporting(1);

include("connection.php");
if (isset($_POST['login_btn'])) {

  if ($_POST['id'] == "" || $_POST['pswd'] == "") {
    $err = "Fill your ID and Password first!";
  } else {
    $d = mysql_query("select * from user where name='{$_POST['id']}' ");
    $row = mysql_fetch_object($d);
    $fid = $row->Name;
    $fpass = $row->Password;
    if ($fid == $_POST['id'] && $fpass == $_POST['pswd']) {
      $_SESSION['sid'] = $_POST['id'];
      header("location:home.php");
    } else {
      $wrong_user = "Incorrect User Name or Password!";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

  <title>mySummer Login Page</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--

TemplateMo 546 Sixteen Clothing

https://templatemo.com/tm-546-sixteen-clothing

-->

  <!-- Additional CSS Files -->
  <link rel="stylesheet" href="assets/css/fontawesome.css">
  <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
  <link rel="stylesheet" href="assets/css/owl.css">

  <link rel="stylesheet" href="../style.css">

</head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="preloader">
    <div class="jumper">
      <div></div>
      <div></div>
      <div></div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!-- Header -->
  <header class="">
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <a class="navbar-brand" href="index.php">
          <h2 style="padding-top: 18px;">my <em>Summer</em></h2>
        </a>
      </div>
    </nav>
  </header>

  <!-- Page Content -->
  <!-- Banner Starts Here -->
  <div class="banner header-text">
    <img src="../pictures/admin_heading.png" style="background-repeat: no-repeat; background-size: cover;" width="100%">
    <div class="text-content">
      <h2>
        <em>
          <br>
          <font class="myH1">Admin Login</font>
        </em>
      </h2>
    </div>
  </div>
  <!-- Banner Ends Here -->



  <!-- <div class="find-us">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Our Location on Maps</h2>
            </div>
          </div>
          <div class="col-md-8"> -->
  <!-- How to change your own map point
	1. Go to Google Maps
	2. Click on your location point
	3. Click "Share" and choose "Embed map" tab
	4. Copy only URL and paste it within the src="" field below
-->
  <!-- <div id="map">
              <iframe src="https://maps.google.com/maps?q=Av.+L%C3%BAcio+Costa,+Rio+de+Janeiro+-+RJ,+Brazil&t=&z=13&ie=UTF8&iwloc=&output=embed" width="100%" height="330px" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
          </div>
          <div class="col-md-4">
            <div class="left-content">
              <h4>About our office</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipisic elit. Sed voluptate nihil eumester consectetur similiqu consectetur.<br><br>Lorem ipsum dolor sit amet, consectetur adipisic elit. Et, consequuntur, modi mollitia corporis ipsa voluptate corrupti.</p>
              <ul class="social-icons">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-behance"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div> -->


  <div class="send-message">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="section-heading">
            <h2>Please Login</h2>
          </div>
        </div>
        <div class="col-md-8">
          <div class="contact-form">
            <form id="contact" action="" method="post">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                  <fieldset>
                    <input name="id" type="text" class="form-control" id="name" placeholder="User Name" required="">
                  </fieldset>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                  <fieldset>
                    <input name="pswd" type="password" class="form-control" id="pswd" placeholder="Password" required="">
                  </fieldset>
                </div>
                <div class="col-lg-12">
                  <fieldset>
                    <button name="login_btn" type="submit" id="form-submit" class="filled-button">Log In</button>
                    <?php echo $wrong_user; ?>
                    <?php echo $err; ?>
                  </fieldset>
                </div>

              </div>
            </form>
          </div>
        </div>


        <div class="col-md-4">
          <div class="container">

            <div class="row">
              <!-- <div class="com_info"> -->

              <h3>
                <font color='orange'>Our Company's Contact Information</font>
              </h3>
              <div class="align-items-end">
                <b><i>mySummer Travel and Tour Co. Ltd,.</i></b>
                <p>No. 35 Zawna Tower A, Room 2002, Thingangyun Tshp., Yangon, Myanmar. </p>
                <p>Tel : <a href='#'>+959000000001</a>
                <p>
                <p>Email : <a href='#'>mysummer.mm@gmail.com</a></p>
              </div>

              <!-- </div> -->
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>


  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="inner-content">
            <p>Copyright &copy; 2023 TravelerVibe.com

              - Design: <a rel="nofollow noopener" href="#" target="_blank">Yae Htet Aung</a></p>
          </div>
        </div>
      </div>
    </div>
  </footer>


  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


  <!-- Additional Scripts -->
  <script src="assets/js/custom.js"></script>
  <script src="assets/js/owl.js"></script>
  <script src="assets/js/slick.js"></script>
  <script src="assets/js/isotope.js"></script>
  <script src="assets/js/accordions.js"></script>


  <script language="text/Javascript">
    cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
    function clearField(t) { //declaring the array outside of the
      if (!cleared[t.id]) { // function makes it static and global
        cleared[t.id] = 1; // you could use true and false, but that's more typing
        t.value = ''; // with more chance of typos
        t.style.color = '#fff';
      }
    }
  </script>


</body>

</html>