<!-- mpc -->
<?php
error_reporting(1);
$id = $_REQUEST['id'];
session_start();

include("connection.php");

if ($_SESSION['sid'] == "") {
  header('location:../sry.html');
} else {
?>
  
  <?php
  $sql = mysql_query("DELETE FROM bookings WHERE id='{$id}'");
  header('location:bookings.php');
  ?>

<?php } ?>