<!-- mpc -->
<?php
error_reporting(1);
$id = $_REQUEST['id'];
session_start();

include("connection.php");

if ($_SESSION['sid'] == "") {
  header('location:../sry.html');
} else {
?>

  <!DOCTYPE html>
  <html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>Add Packages</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <link href="../style.css" rel="stylesheet">
    <!--

TemplateMo 546 my Clothing

https://templatemo.com/tm-546-my-clothing

-->

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
    <link rel="stylesheet" href="assets/css/owl.css">

  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
      <div class="jumper">
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php">
            <h2>Traveler<em>Vibe</em></h2>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <?php
              echo "
                <li class='nav-item'>
                    <a class='nav-link' href='home.php'>Home
                    <span class='sr-only'>(current)</span>
                    </a>
                </li>
                <li class='nav-item'>
                    <a class='nav-link' href='add_package.php'>Add Package
                    </a>
                </li>
                <li class='nav-item'>
                    <a class='nav-link' href='admin_packages.php'>Packages</a>
                </li>
                <li class='nav-item active'>
                    <a class='nav-link' href='#'>Bookings</a>
                </li>
                <li class='nav-item'>
                    <a class='nav-link' href='admin_feedbacks.php'>Feedbacks</a>
                </li>
                <li class='nav-item'>
                    <a class='nav-link' href='logout.php'>Log Out</a>
                </li>";

              ?>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="banner header-text">
      <img src="../pictures/package_heading.png" style="background-repeat: no-repeat; background-size: cover;" width="100%">
      <div class="text-content">
        <br><br><br>
        <h2>
          <em>
            <font class="myH1">Bookings</font>
          </em>
        </h2>
      </div>
    </div>
    <!-- Banner Ends Here -->

    <?php
    // error_reporting(1);
    // include("connection.php");
    $arr = mysql_query("SELECT * FROM bookings WHERE id='{$id}'");
    $row = mysql_fetch_object($arr);
    // $id = $row->ID;
    $pkgName = $row->PkgName;
    $pkgId = $row->PkgID;
    $price = $row->Price;
    $name = $row->Name;
    $mobile = $row->Mobile;
    $email = $row->Email;
    $status = $row->Status;

    $nPkgName = $_POST['nPkgName'];
    $nPkgId = $_POST['nPkgId'];
    $nPrice = $_POST['nPrice'];
    $nName = $_POST['nName'];
    $nMobile = $_POST['nMobile'];
    $nEmail = $_POST['nEmail'];
    $selValue = $_POST['sel_box'];

    if (isset($_POST['update_btn'])) {
      if ($pkgName == $nPkgName && $pkgId == $nPkgId && $name == $nName && $email == $nEmail && $mobile == $nMobile && $status == $selValue) {
        $err = "No Change Detected!";
        // return;
      } else {
        mysql_query("UPDATE bookings SET PkgName='$nPkgName', PkgID='$nPkgId', Price='$nPrice', Name='$nName', Mobile='$nMobile', Email='$nEmail', Status='$selValue' WHERE id='{$id}'");
        header('location:bookings.php');
      }
    }
    if (isset($_POST['cancel_btn'])) {
      header('location:bookings.php');
    }


    ?>

    <div class="send-message">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Edit Booking</h2>
              <h5><?php echo "Package ID: $id"; ?></h5>
              <h5><?php echo "$err"; ?></h5>
            </div>
          </div>

          <!-- 
            $pkgName = $row->PkgName;
            $pkgID = $row->PkgID;
            $price = $row->Price;
            $name = $row->Name;
            $mobile = $row->Mobile;
            $email = $row->Email;
            $status = $row->Status; -->

          <div class="col-md-7">
            <div class="contact-form">

              <?php
              echo "
                <form method='post'>
                    <div class='form-group row'>
                      <label for='packageName' class='col-sm-3 col-form-label'> Package Name </label>
                      <div class='col-sm-9'>
                        <input name='nPkgName' type='text' class='form-control' id='packageName' placeholder='' value='$pkgName'>
                      </div>
                    </div>

                    <div class='form-group row'>
                      <label for='packageId' class='col-sm-3 col-form-label'> Package ID </label>
                      <div class='col-sm-9'>
                        <input name='nPkgId' type='text' class='form-control' id='packageId' placeholder='' value='$pkgId'>
                      </div>
                    </div>

                    <div class='form-group row'>
                      <label for='Price' class='col-sm-3 col-form-label'> Price </label>
                      <div class='col-sm-9'>
                        <input name='nPrice' type='number' class='form-control' id='Price' placeholder='' value='$price' readonly>
                      </div>
                    </div>
                    
                    <div class='form-group row'>
                      <label for='name' class='col-sm-3 col-form-label'> Customer Name </label>
                      <div class='col-sm-9'>
                        <input name='nName' type='text' class='form-control' id='name' placeholder='' value='$name' required=''>
                      </div>
                    </div>

                    <div class='form-group row'>
                      <label for='email' class='col-sm-3 col-form-label'> Mobile Number </label>
                      <div class='col-sm-9'>
                        <input name='nEmail' type='email' class='form-control' id='email' placeholder='' value='$email' required=''>
                      </div>
                    </div>

                    <div class='form-group row'>
                      <label for='mobile' class='col-sm-3 col-form-label'> Mobile Number </label>
                      <div class='col-sm-9'>
                        <input name='nMobile' type='text' class='form-control' id='mobile' placeholder='' value='$mobile' required=''>
                      </div>
                    </div>


                    <div class='form-group row'>
                        <label for='my_sel'  class='col-sm-3 col-form-label'>Select&nbsp;Status</label>
                        <div class='col-sm-9'>
                          <select name='sel_box' id='my_sel' class='form-control custom-select' required=''>
                            <option value='Pending'>Pending</option>
                            <option value='Paid'>Paid</option>
                          </select>
                        </div>
                    </div>

                    <div class='row col-lg-12 justify-content-md-center'>
                      <div class='col-md-auto '>
                        <fieldset>
                          <button name='update_btn' type='submit' class='btn filled-button'>Update</button>
                        </fieldset>
                      </div>

                      <div class='col-md-auto '>
                        <fieldset>
                          <button name='cancel_btn' type='submit' class='btn filled-button'>Cancel</button>
                        </fieldset>
                      </div>
                    </div>

                  
                </form>
                  ";
              ?>


            </div>
          </div>
        </div>
      </div>
    </div>


    <footer>
      <?php
      if ($anyPackage != "") {
        echo "
        <div class='container'>
          <div class='row'>
            <div class='col-md-12'>
              <a class='filled-button' href='#'>Go to top</a>
            </div>
          </div>
        </div>
        ";
      }
      ?>


      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="inner-content">
              <p>Copyright &copy; 2023 TravelerVibe.com

                - Design: <a rel="nofollow noopener" href="#" target="_blank">Yae Htet Aung</a></p>
            </div>
          </div>
        </div>
      </div>

    </footer>


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/accordions.js"></script>


    <script language="text/Javascript">
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t) { //declaring the array outside of the
        if (!cleared[t.id]) { // function makes it static and global
          cleared[t.id] = 1; // you could use true and false, but that's more typing
          t.value = ''; // with more chance of typos
          t.style.color = '#fff';
        }
      }
    </script>


  </body>

  </html>

<?php } ?>