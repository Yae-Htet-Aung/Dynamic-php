<?php
session_start();
error_reporting(1);
if ($_SESSION['sid'] == "") {
  header('location:../sry.html');
} else {
?>

  <?php
  include("connection.php");
  $id = $_POST['id'];
  $picture = $_FILES['img']['name'];
  $package = $_POST['pkg'];
  $info = $_POST['info'];
  $price = $_POST['price'];

  if (isset($_POST['add_btn'])) {
    $insert = "INSERT INTO Packages(ID, Picture, Package, Info, Price) VALUES('$id','$picture','$package', '$info', '$price')";
    $result = mysql_query($insert) or die("save items query fail.");

    if ($result) {
      mkdir("image/$i");
      move_uploaded_file($_FILES['img']['tmp_name'], "image/$i" . $_FILES['img']['name']);

      $reply = "<font color='teal'><h6> Package added successfully :) </h6></font>";
      header("location: admin_packages.php?rp=$reply");
      exit;
    } else {
      $reply = "<font color='red'><h6> Item is not inserted! :( </h6></font>";
    }
  }
  mysql_close($con);
  ?>

  <!DOCTYPE html>
  <html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>Add Packages</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <link href="../style.css" rel="stylesheet">

    <!--

TemplateMo 546 my Clothing

https://templatemo.com/tm-546-my-clothing

-->

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
    <link rel="stylesheet" href="assets/css/owl.css">

  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
      <div class="jumper">
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php">
            <h2>traveler<em>vibe</em></h2>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <?php
              echo "
              <li class='nav-item'>
                  <a class='nav-link' href='home.php'>Home
                  <span class='sr-only'>(current)</span>
                  </a>
              </li>
              <li class='nav-item active'>
                <a class='nav-link' href='#'>Add Package
                  <span class='sr-only'>(current)</span>
                </a>
              </li>
              <li class='nav-item'>
                <a class='nav-link' href='admin_packages.php'>Packages</a>
              </li>
              <li class='nav-item'>
                <a class='nav-link' href='bookings.php'>Bookings</a>
              </li>
              <li class='nav-item'>
                <a class='nav-link' href='admin_feedbacks.php'>Feedbacks</a>
              </li>
              <li class='nav-item'>
                <a class='nav-link' href='logout.php'>Log Out</a>
              </li>";

              ?>

            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="banner header-text">
      <img src="../pictures/admin_heading.png" style="background-repeat: no-repeat; background-size: cover;" width="100%">
      <div class="text-content">
        <h2>
          <em>
            <br>
            <font class="myH1">Add Packages</font>
          </em>
        </h2>
      </div>
    </div>
    <!-- Banner Ends Here -->


    <div class="send-message">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Add a new package</h2>
              <?php //echo $reply; ?>
            </div>
          </div>
          <!-- new start -->
          <form method='post' class='col-md-7' enctype="multipart/form-data">

            <div class='form-group row'>
              <label for='Id' class='col-sm-4 col-form-label'> Package&apos;s ID </label>
              <div class='col-sm-8'>
                <input name='id' type='text' class='form-control form-control-sm' id='Id' required=''>
              </div>
            </div>

            <div class='form-group row'>
              <label for='Picture' class='col-sm-4 col-form-label'> Upload Picture </label>
              <div class='col-sm-8'>
                <input name='img' type='file' class='form-control-file btn-outline-info' id='Picture' required=''>
              </div>
            </div>

            <div class='form-group row'>
              <label for='package' class='col-sm-4 col-form-label'> Package&apos;s Name </label>
              <div class='col-sm-8'>
                <input name='pkg' type='text' class='form-control form-control-sm' id='package' required=''>
              </div>
            </div>

            <div class='form-group row'>
              <label for='infoL' class='col-sm-4 col-form-label'> Package&apos;s Description </label>
              <div class='col-sm-8'>
                <!-- <input name='info' type='text' class='form-control form-control-sm' id='info' required=''> -->
                <textarea name='info' type='text' rows='6' class='form-control form-control-sm' id='infoL' required=''></textarea>
              </div>
            </div>

            <div class='form-group row'>
              <label for='package' class='col-sm-4 col-form-label'> Package&apos;s Price </label>
              <div class='col-sm-8'>
                <input name='price' type='text' class='form-control form-control-sm' id='package' required=''>
              </div>
            </div>

            <div class='row col-md-12 justify-content-md-center'>
              <div class='col-md-auto '>
                <fieldset>
                  <button name="add_btn" type="submit" class="btn btn-outline-info ">Add Package </button>
                </fieldset>
              </div>
            </div>
          </form>
          <!-- new end -->


          <div class="col-md-5">
            <ul class="accordion">

              <li>
                <a> Warning </a>
                <div class="content">
                  <p> While filling up the form to add package, <font color='red'><b>DO NOT USE</b></font> apostrophe. If apostrophe is necessary, must use html entities. </p>
                  <p><font color='red'><b>DO NOT USE</b></font> same package ID or same picture names. </p>
                </div>
              </li>

              <li>
                <a>How to add a package?</a>
                <div class="content">
                  <p>Fill all the field in the form.<br><br>Upload a photo for your package by clicking "Choose File" button.<br><br>Click "Add" button.</p>
                </div>
              </li>

              <li>
                <a>Where to view uploaded packages?</a>
                <div class="content">
                  <p>Go to "Packages" menu beside "Add Package" menu.</p>
                </div>
              </li>

            </ul>
          </div>
        </div>
      </div>
    </div>


    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="inner-content">
              <p>Copyright &copy; 2023 TravelerVibe.com

                - Design: <a rel="nofollow noopener" href="#" target="_blank">Yae Htet Aung</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  <?php }  ?>


  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


  <!-- Additional Scripts -->
  <script src="assets/js/custom.js"></script>
  <script src="assets/js/owl.js"></script>
  <script src="assets/js/slick.js"></script>
  <script src="assets/js/isotope.js"></script>
  <script src="assets/js/accordions.js"></script>


  <script language="text/Javascript">
    cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
    function clearField(t) { //declaring the array outside of the
      if (!cleared[t.id]) { // function makes it static and global
        cleared[t.id] = 1; // you could use true and false, but that's more typing
        t.value = ''; // with more chance of typos
        t.style.color = '#fff';
      }
    }
  </script>


  </body>

  </html>