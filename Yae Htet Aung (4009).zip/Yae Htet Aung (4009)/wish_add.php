<?php
error_reporting(1);
session_start();

include("connection.php");

if ($_SESSION['sid'] == "") {
    header('location:sry.html');
} else {
?>
    <?php
    $eId = $_REQUEST["eId"];
    $pkg_name = $_REQUEST["pkgName"];

    $preCheck = mysql_query("SELECT * FROM wish_list WHERE Email='{$eId}'");
    while ($row = mysql_fetch_object($preCheck)) {
        $pre = $row->PackageName;
        // echo "pre= $pre<br>";
        if (empty($pre)) {
            // echo "pre= $pre";
            break;
        }
    }

    // echo "Is there any pkgs? >> $pre<br><Hr>";

    if ($pre == "") {
        // echo "RUN >> pre empty";
        $insert = "INSERT INTO wish_list(Email, PackageName) VALUES('$eId', '$pkg_name')";
        $result = mysql_query($insert) or die("Save items query failed!");

        if ($result) {
            $reply = "Your Wish added successfully :)";
        } else {

            $reply = "Your Wish wasn't added successfully! :(";
        }
        mysql_close($con);
        header("location:packages_reg.php?eId=$eId&rp=$reply");
        return;
    } else {

        $checkUser = mysql_query("SELECT * FROM wish_list WHERE Email='{$eId}'");
        while ($row = mysql_fetch_object($checkUser)) {
            $emailName = $row->Email;
            $pkgName = $row->PackageName;

            $ns_pkg_name = preg_replace('/\s+/', '', $pkg_name);
            $ns_pkgName = preg_replace('/\s+/', '', $pkgName);

            // echo "Pkg length form Packages:" . strlen($pkg_name) . "<br>";
            // echo "Pkg length form Database:" . strlen($pkgName) . "<br><hr>";
            // echo "Pkg name form Packages:" . $ns_pkg_name . "<br>";
            // echo "Pkg name form Database:" . $ns_pkgName . "<br><hr>";

            // echo "pkg str len test: " . strlen($ns_pkg_name) . " ? " . strlen($ns_pkgName) . "<br><br>";

            if ($ns_pkg_name != $ns_pkgName) {
                // echo "PKG>> $ns_pkg_name # ***** DB >>  $ns_pkgName # <br><br> *** DIFFERENT! *** <br><br> <hr>";
                $switch = 1;
            } else {
                // echo "<br> PKG>> $ns_pkg_name # ***** DB >>  $ns_pkgName # <br> *** SAME! *** <br><br> <hr>";
                $switch = 0;
                break;
            }
        } // check user while

        // echo "switch value >> $switch";
        if ($switch == 1) {
            $insert = "INSERT INTO wish_list(Email, PackageName) VALUES('$eId', '$pkg_name')";
            $result = mysql_query($insert) or die("Save items query failed!");

            if ($result) {
                $reply = "Your Wish added successfully :)";
            } else {

                $reply = "Your Wish wasn't added successfully! :(";
            }
            mysql_close($con);
            header("location:packages_reg.php?eId=$eId&rp=$reply");
            return;
        } else {
            $reply = "Your Wish's already Existed! Please choose others.";
            mysql_close($con);
            header("location:packages_reg.php?eId=$eId&rp=$reply");
            return;
        }
    } // ($cnt == 0 && $pre == "") else

    ?>
<?php } ?>