<?php
error_reporting(1);
session_start();

include("connection.php");

if ($_SESSION['sid'] == "") {
    header('location:sry.html');
} else {
?>
    <?php
    $eId = $_REQUEST["eId"];
    $pkgName = $_REQUEST["pName"];

    $del = mysql_query("DELETE FROM wish_list WHERE Email='{$eId}' AND PackageName='{$pkgName}' ") or die("Delete query failed!");
    $rp = "was Removed Successfully.";
    header("location:wish_reg.php?eId=$eId&rp=$rp&pName=$pkgName");
    ?>
<?php } ?>