<?php
error_reporting(1);

include("connection.php");

if ($_REQUEST['log'] == 'out') {
  session_destroy();
  header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

  <title>TravelerVibe.com - Packages</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--

TemplateMo 546 my Clothing

https://templatemo.com/tm-546-my-clothing

-->

  <!-- Additional CSS Files -->
  <link rel="stylesheet" href="assets/css/fontawesome.css">
  <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
  <link rel="stylesheet" href="assets/css/owl.css">

  <!-- my style -->
  <link rel="stylesheet" href="style.css" type="text/css">
  <script src="https://kit.fontawesome.com/91371d62e4.js" crossorigin="anonymous"></script>

</head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="preloader">
    <div class="jumper">
      <div></div>
      <div></div>
      <div></div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!-- Header -->
  <header class="">
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <a class="navbar-brand" href="index.php">
          <h2>Traveler<em>Vibe</em></h2>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="packages.php">Packages</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="register.php">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php">Login</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>

  <!-- Page Content -->
  <!-- Banner Starts Here -->
  <div class="banner header-text">
    <img src="pictures/package_heading.png" style="background-repeat: no-repeat; background-size: cover;" width="100%">
    <div class="text-content">
      <br><br><br>
      <h2>
        <em>
          <font class="myH1">Special Packages</font>
        </em>
      </h2>
    </div>
  </div>
  <!-- Banner Ends Here -->


  <div class="products">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="section-heading">
            <?php
            error_reporting(1);
            if ($_REQUEST['Name'] == "") {
              echo "<h6><font color=red> Please Register or Login to Book Ant Packages.</font></h6>";
            } 
            // else {
            //   echo "<h6> Welcome <font color=green>" . $_REQUEST['Name'] . " </font></h6><br>
            // <h6><font color='teal'>You have created your account successfully!!! 
            // Thank you for registration. </font></h6>
            // <h6><font color='teal'>" . $_REQUEST['Reply'] . " </font></h6>";
            // } 
            ?>
          </div>
        </div>

        <?php
        error_reporting(1);
        include("connection.php");
        $sel = mysql_query("SELECT * FROM packages ");

        // echo '<div class="col-md-12"><div class="filters-content"><div class="row ">';
        echo "
<div class='container'>
  <div class='col-md-12'>
    <div class='row'>
    ";

        $n = 0;
        while ($arr = mysql_fetch_array($sel)) {
          $pic = $arr['Picture'];
          $pkg_name = $arr['Package'];
          $info = $arr['Info'];
          $id = $arr['ID'];
          $price = $arr['Price'];


          echo "

                <div class='col-md-4'>
                  <div class='product-item'>
                  
                    <div class='down-content'>
                      <a href='#'><img src='admin/image/$pic' height='150' width='200'></a>
                    </div>

                    <div class='down-content'>
                      <h4><a href='#'><b>$pkg_name</b></a></h4>
        
                      <h4>ID: $id</h4>
                      
                      <p align='justify'> $info </p>

                      <h4 align='right'><font color='black'> &dollar;$price </font></h4>
                    </div>

                    <div class='down-content'>
                      <center>
                        <a href='register.php?pkgID=$pkg_name' class='filled-button'>Book Now</a>
                      </center>
                    </div>

                  </div>
                  
                </div>";

          $n++;
        }
        if ($n % 3 == 0) {
          echo "</div>";
        }
        echo "
</div></div>";
        ?>

      </div>
    </div>
  </div>

  <footer>

    <!-- <div class="container"> -->
    <div class="row">
      <div class="col-md-12">
        <!-- <div class="inner-content"> -->
        <?php echo "<a class='filled-button' href='packages.php'>Go to top</a>";
        ?>
        <!-- </div> -->
      </div>
    </div>
    <!-- </div> -->

    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="inner-content">
            <p>Copyright &copy; 2023 TravelerVibe.com

              - Design: <a rel="nofollow noopener" href="#" target="_blank">Yae Htet Aung</a></p>
          </div>
        </div>
      </div>
    </div>
  </footer>


  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


  <!-- Additional Scripts -->
  <script src="assets/js/custom.js"></script>
  <script src="assets/js/owl.js"></script>
  <script src="assets/js/slick.js"></script>
  <script src="assets/js/isotope.js"></script>
  <script src="assets/js/accordions.js"></script>


  <script language="text/Javascript">
    cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
    function clearField(t) { //declaring the array outside of the
      if (!cleared[t.id]) { // function makes it static and global
        cleared[t.id] = 1; // you could use true and false, but that's more typing
        t.value = ''; // with more chance of typos
        t.style.color = '#fff';
      }
    }
  </script>


</body>

</html>