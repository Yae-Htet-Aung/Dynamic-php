<?php
session_start();
error_reporting(1);

include("connection.php");
$eId = $_REQUEST["eId"];
$pId = $_REQUEST["pId"];
$rp = $_REQUEST["rp"];


if ($_SESSION['sid'] == "") {
  header('location:sry.html');
} else {
?>

  <!DOCTYPE html>
  <html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title> Profile </title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--

TemplateMo 546 my Clothing

https://templatemo.com/tm-546-my-clothing

-->

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
    <link rel="stylesheet" href="assets/css/owl.css">

    <!-- add -->
    <!-- <script src="https://kit.fontawesome.com/91371d62e4.js" crossorigin="anonymous"></script> -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">

    <!-- yae -->
    <link rel="stylesheet" href="style.css">
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
      <div class="jumper">
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php">
            <h2>Traveler<em>Vibe</em></h2>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <!-- <li class="nav-item">
                <a class="nav-link" href="index_reg.php?eId = $eId">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li> -->
              <!-- mni -->
              <?php
              echo "
              <li class='nav-item'>
                <a href='index_reg.php?eId=$eId' class='nav-link'>Home</a>
                <span class='sr-only'>(current)</span>
              </li>

              <li class='nav-item'>
                <a href='packages_reg.php?eId=$eId' class='nav-link'>Packages</a>
                <span class='sr-only'>(current)</span>
              </li>

              <li class='nav-item'>
                <a href='contact_reg.php?eId=$eId' class='nav-link'>Contact Us</a>
                <span class='sr-only'>(current)</span>
              </li>

              <li class='nav-item'>
                <a href='wish_reg.php?eId=$eId' class='nav-link'>Wish List</a>
                <span class='sr-only'>(current)</span>
              </li>

              <li class='nav-item active'>
                <a href='#' class='nav-link'>Profile</a>
                <span class='sr-only'>(current)</span>
              </li>
              ";
              ?>

              <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="banner header-text">
      <img src="pictures/register_heading.png" style="background-repeat: no-repeat; background-size: cover;" width="100%">
      <div class="text-content">
        <br><br><br>
        <h2>
          <em>
            <font class="myH1">Booking Receipt</font>
          </em>
        </h2>
        <?php
        $d = mysql_query("SELECT * FROM registers WHERE Email='{$eId}' ");
        $row = mysql_fetch_object($d);
        $name = $row->Name;
        $address = $row->Address;
        $mobile = $row->Mobile;
        echo "
          
            <font class='myRp'><h3>$name, this is your booked receipt :) </h3></font>
            $rp
          
          ";
        ?>
      </div>
    </div>
    <!-- Banner Ends Here -->

    <?php
    $preCheck = mysql_query("SELECT * FROM bookings WHERE Email='{$eId}' AND Status='Paid' ");
    while ($row = mysql_fetch_object($preCheck)) {
      $anyBooking = $row->PkgID;
      
      if (empty($anyBooking)) {
        break;
      }
    }

    if ($anyBooking == "") {
      echo "
          <div class='send-message'>
            <div class='container'>
                <div class='row'>
                    <div class='col-12'>
                        <div class='section-heading'>
                          <center>
                            <h2>Nothing to show :( </h2>
                          </center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
          ";
    } else {
      echo "
      <div class='send-message'>
        <div class='container'>
          <div class='row'>

            <div class='col-12'>
              <div class='section-heading mb-3'>
                <h4> Customer Information </h4>
              </div>
            </div>

            <form class='col-6'>

              <div class='form-group row mb-1 ml-1'>
                  <label for='name' class='col-2 col-form-label form-control-sm'> Name </label>
                  <div class='col-10'>
                      <input type='text' class='form-control-plaintext form-control-sm' id='name' value=': $name'>
                  </div>
              </div>

              <div class='form-group row mb-1 ml-1'>
                  <label for='email' class='col-2 col-form-label form-control-sm'> Email </label>
                  <div class='col-10'>
                      <input type='text' class='form-control-plaintext form-control-sm' id='email' value=': $eId'>
                  </div>
              </div>

              <div class='form-group row mb-1 ml-1'>
                  <label for='address' class='col-2 col-form-label form-control-sm'> Address </label>
                  <div class='col-10'>
                      <input type='text' class='form-control-plaintext form-control-sm' id='address' value=': $address'>
                  </div>
              </div>

              <div class='form-group row mb-1 ml-1'>
                  <label for='mobile' class='col-2 col-form-label form-control-sm'> Mobile </label>
                  <div class='col-10'>
                      <input type='text' class='form-control-plaintext form-control-sm' id='mobile' value=': $mobile'>
                  </div>
              </div>

            </form>

            <div class='col-6'>
              <img src='pictures/myLogo.png' width='30%' align='right'>
            </div>

          </div>
        </div>
      </div>

      <div class='send-message mt-3'>
        <div class='container'>
          <div class='row'>

            <div class='col-12'>
              <div class='section-heading mb-3'>
                <h4> Package Information </h4>
              </div>
            </div>

          </div>
        </div>
      </div>

      <div class='container'>
        <table class='table'>

          <tr class='table-info col-12'>
            <th class='col-2'>
              DESCRIPTION
            </th>
            <th class='col-2'>
              RATE
            </th>
            <th class='col-2'>
              TAX
            </th>
            <th class='col-2'>
              AMOUNT
            </th>
          </tr>";
      error_reporting(1);
      include("connection.php");

      $bookingList = mysql_query("SELECT * FROM bookings WHERE Email='{$eId}' AND Status='Paid'");

      while ($take = mysql_fetch_object($bookingList)) {
        $pkgName = $take->PkgName;
        $pkgId = $take->PkgID;
        $price = $take->Price;

        $tax = .05 * $price;
        $subTotal = $tax + $price;
        $total += $subTotal;

        echo " 
              <tr class='table-light col-12'>
                <td class='col-2'>
                  <p class='mb-0'><i> $pkgName </i></p>
                  <p  class='mb-0'>$pkgId </p>
                </td>
                <td class='col-2'>
                  <p> &dollar;$price </p>
                </td>
                <td class='col-2'>
                  <p> &dollar;$tax </p>
                </td>
                <td class='col-2'>
                  <p> &dollar;$subTotal </p>
                </td>
              </tr>";
      }
      
      echo "
            </table>
          </div>";

echo "
            <div class='container'>
              <table class='table'>
                <tr class='table-warning col-12'>
                  <td class='col-6'>
                    <h6><b> Total (Including Tax) </b></h6>
                  </td>

                  <td class='col-2'>
                    <h6> &dollar;$total </h6>
                  </td>
                </tr>
              </table>
            </div>
          
        </div>
      </div>";

    } // else
    ?>

    <footer>
      <?php
      if ($anyBooking == "") {
        echo "
        <h4>
          <font class='myErr'>You will receive a receipt after paying for the package.</font>
        </h4>";
      } else {
        echo "
      <div class='container'>
        <div class='row'>
          <div class='col-12'>
            <a class='filled-button' href='#'>Go to top</a>
          </div>
        </div>
      </div>
      ";
      }
      ?>


      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="inner-content">
              <p>Copyright &copy; 2020 TravelerVibe.com.

                - Design: <a rel="nofollow noopener" href="https://templatemo.com" target="_blank">TemplateMo</a></p>
            </div>
          </div>
        </div>
      </div>

    </footer>


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/accordions.js"></script>

    <script language="text/Javascript">
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t) { //declaring the array outside of the
        if (!cleared[t.id]) { // function makes it static and global
          cleared[t.id] = 1; // you could use true and false, but that's more typing
          t.value = ''; // with more chance of typos
          t.style.color = '#fff';
        }
      }
    </script>

  </body>

  </html>

<?php } ?>