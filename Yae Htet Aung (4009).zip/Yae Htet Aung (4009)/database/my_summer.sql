-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 13, 2023 at 06:58 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `my_summer`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE IF NOT EXISTS `bookings` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PkgName` varchar(100) NOT NULL,
  `PkgID` varchar(30) NOT NULL,
  `Price` double NOT NULL,
  `Name` varchar(60) NOT NULL,
  `Mobile` bigint(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Status` varchar(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`ID`, `PkgName`, `PkgID`, `Price`, `Name`, `Mobile`, `Email`, `Status`) VALUES
(1, 'Ngwesaung Beach Trip', 'Package 3', 650, 'Taylor Swift', 999777006, 'taylor@gmail.com', 'Pending'),
(2, 'Nyaung Oo Hpi Beach Trip', 'Package 5', 1999, 'Taylor Swift', 999777006, 'taylor@gmail.com', 'Paid'),
(3, 'Ngwesaung Beach Trip', 'Package 3', 650, 'User 1', 755111001, 'user1@gmail.com', 'Pending'),
(4, 'Mergui Archipelago Trip', 'Package 4', 1999, 'User 1', 755111001, 'user1@gmail.com', 'Paid'),
(5, 'Nga Pa Li Beach Trip', 'Package 2', 1790, 'User 2', 755111002, 'user2@gmail.com', 'Pending'),
(6, 'Mergui Archipelago Trip', 'Package 4', 1999, 'User 2', 755111002, 'user2@gmail.com', 'Paid'),
(7, 'Chaung Tha Beach Trip', 'Package 1', 690, 'User 2', 755111002, 'user2@gmail.com', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `Name` char(60) NOT NULL,
  `Mobile` bigint(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Message` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Name`, `Mobile`, `Email`, `Message`) VALUES
('Yae', 776155155, 'yae@gmail.com', 'Unregistered Feedback Test 1'),
('Kelvin', 775155001, 'kelvin@gmail.com', 'Registered Feedback Test 1');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE IF NOT EXISTS `packages` (
  `ID` varchar(30) NOT NULL,
  `Picture` varchar(100) NOT NULL,
  `Package` varchar(200) NOT NULL,
  `Info` longtext NOT NULL,
  `Price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`ID`, `Picture`, `Package`, `Info`, `Price`) VALUES
('Package 3', 'ngweSaung.jpg', 'Ngwesaung Beach Trip', 'Ngwesaung, also spelt Ngwe Hsaung, is a beach resort located 48 km west of Pathein, Ayeyarwady Region, Myanmar. It is the namesake of Ngwesaung Subtownship, Pathein Township. In 2014, the town of Ngwesaung had 10,732 people. The beach is 5 hours drive, with no traffic, away from the principal city of Yangon, and an airport is in the works. ', 650),
('Package 4', 'myeikArchipelago.jpg', 'Mergui Archipelago Trip', 'The Mergui Archipelago is located in far southern Myanmar and is part of the Tanintharyi Region. It consists of more than 800 islands, varying in size from very small to hundreds of square km, all lying in the Andaman Sea off the western shore of the Malay Peninsula near its landward (northern) end where it joins the rest of Indochina.', 1999),
('Package 1', 'ngweSaung.jpg', 'Chaung Tha Beach Trip', 'Of the three main beach resorts on Myanmar&apos;s Bay of Bengal coast, Chaung Tha is the most down to earth, and you can find the largest number of locals on holiday here. Chaungtha is a town and beach resort located in Shwethaungyan Subtownship, Pathein Township, Ayeyar Wady Region, Myanmar. It is more commonly known, is about 5 hours&apos; drive away from Yangon.', 690),
('Package 5', 'NyaoOoPhee.jpg', 'Nyaung Oo Hpi Beach Trip', 'This island is one of the must-visit places in Myeik Archipelago. You have to get to Kawthaung in Thanintharyi region in South Myanmar to visit this island. Nyaung Oo Phee and the regions was previously under the purview of pirates. Since 1940, The military controlled the area and it was off limits to all. In 2015 this area was opened up to tourism.', 1999),
('Package 2', 'ngapali.jpg', 'Nga Pa Li Beach Trip', 'Ngapali Beach is a beach located 7 km from the town of Thandwe, Rakhine State, Myanmar. It is the most famous beach in Myanmar and is a popular tourist destination. The name &apos;&apos;Ngapali&apos;&apos;, has no meaning in Burmese, but comes from the Italian &apos;&apos;Napoli&apos;&apos; (Naples). Myanmar&apos;s political climate means that Ngapali is not as well publicized as other beaches of Southeast Asia.', 1790);

-- --------------------------------------------------------

--
-- Table structure for table `registers`
--

CREATE TABLE IF NOT EXISTS `registers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` char(60) NOT NULL,
  `Mobile` bigint(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Address` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `registers`
--

INSERT INTO `registers` (`ID`, `Name`, `Mobile`, `Email`, `Password`, `Address`) VALUES
(1, 'User 1', 755111001, 'user1@gmail.com', 'user1', 'Yangon'),
(2, 'User 2', 755111002, 'user2@gmail.com', 'user2', 'Seoul, Korea.'),
(3, 'User 3', 755111003, 'user3@gmail.com', 'user3', 'Bamaw'),
(14, 'User 4', 755111004, 'user4@gmail.com', 'user4', 'Pathein'),
(20, 'Kelvin', 755111005, 'kelvin@gmail.com', 'kelvin', 'California'),
(21, 'Taylor Swift', 999777006, 'taylor@gmail.com', 'taylor', 'Hendersonville, Tennessee');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `Name` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Name`, `Password`) VALUES
('admin', 'yae');

-- --------------------------------------------------------

--
-- Table structure for table `wish_list`
--

CREATE TABLE IF NOT EXISTS `wish_list` (
  `wID` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `PackageName` char(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wish_list`
--

INSERT INTO `wish_list` (`wID`, `Email`, `PackageName`) VALUES
('', 'taylor@gmail.com', 'Nga Pa Li Beach Trip'),
('', 'taylor@gmail.com', 'Nyaung Oo Hpi Beach Trip'),
('', 'user1@gmail.com', 'Ngwesaung Beach Trip'),
('', 'user1@gmail.com', 'Mergui Archipelago Trip'),
('', 'user2@gmail.com', 'Nga Pa Li Beach Trip'),
('', 'user2@gmail.com', 'Chaung Tha Beach Trip'),
('', 'user2@gmail.com', 'Ngwesaung Beach Trip');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
