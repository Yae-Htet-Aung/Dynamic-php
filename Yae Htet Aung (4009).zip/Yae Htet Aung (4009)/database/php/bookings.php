<?php
include("connection.php");

$create = "CREATE TABLE bookings (

ID int auto_increment primary key, 
PkgName varchar(100) not null,
PkgID varchar(30) not null,
Price float(30) not null,
Name varchar(60) not null,
Mobile bigint(20) not null,
Email varchar(30) not null,
Status varchar(10) not null

)";

if (mysql_query($create)) {
  echo "table created successfully";
} else {
  echo "Error creating database: " . mysql_error();
}
