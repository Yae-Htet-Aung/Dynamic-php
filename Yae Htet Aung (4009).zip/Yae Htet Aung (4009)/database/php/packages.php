<?php
include("connection.php");

$create="CREATE TABLE Packages (
ID varchar(30) not null, 
Picture varchar(100) not null,
Package varchar(100) not null,
Info varchar(200) not null,
Price float(30) not null
)";

if (mysql_query($create)) {
echo "Packages table created successfully";
} else {
echo "Error creating database: " . mysql_error();
}
