<?php
include("connection.php");

$create="CREATE TABLE user (
-- ID int auto_increment primary key, 
Name varchar(30) not null,
Password varchar(30) not null
)";

if (mysql_query($create)) {
echo "table created successfully";
} else {
echo "Error creating database: " . mysql_error();
}
