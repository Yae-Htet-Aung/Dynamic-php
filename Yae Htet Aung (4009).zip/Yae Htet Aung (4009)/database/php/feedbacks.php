<?php
include("connection.php");

$create="CREATE TABLE feedback (
-- ID int auto_increment primary key, 
Name char(60) not null,
Mobile bigint not null,
Email varchar(50) not null,
Message text(150) not null
)";

if (mysql_query($create)) {
echo " table created successfully";
} else {
echo "Error creating database: " . mysql_error();
} 
