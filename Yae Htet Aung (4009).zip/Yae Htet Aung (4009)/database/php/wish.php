<?php
include("connection.php");

$create= "CREATE TABLE wish_list (
wID varchar(30) not null,
Email varchar(30) not null,
PackageName char(60) not null
)";

if (mysql_query($create)) {
echo "Wish list table created successfully ";
} else {
echo "Error creating database: " . mysql_error();
}
