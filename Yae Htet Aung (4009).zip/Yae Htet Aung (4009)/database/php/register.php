<?php
include("connection.php");

$create="CREATE TABLE registers (
ID int auto_increment primary key, 
Name varchar(60) not null,
Mobile bigint(20) not null,
Email varchar(30) not null,
Password varchar(20) not null,
Address varchar(100) not null
)";

if (mysql_query($create)) {
echo " table created successfully";
} else {
echo "Error creating database: " . mysql_error();
}
