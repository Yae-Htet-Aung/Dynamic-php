<!-- Session -->
<?php
error_reporting(1);
session_start();
include("connection.php");
$e_id = $_REQUEST["eID"];


if ($_SESSION['sid'] == "") {
    header('location:sry.html');
} else {
?>
    <!-- ... -->
<?php } ?>

<!-- ----------------------------------------------------- -->

<!-- Retrieve -->
<?php
error_reporting(1);
include("connection.php");
$sel = mysql_query("SELECT * FROM packages ORDER BY ID DESC");

while ($arr = mysql_fetch_array($sel)) {
    $pic = $arr['Picture'];
    // echo "";
}
?>

<!-- ----------------------------------------------------- -->

<!-- Retrieve -->
<?php
$d = mysql_query("select * from registers where Email='{$e_id}'");
$row = mysql_fetch_object($d);
$name = $row->Name;
?>

<!-- ----------------------------------------------------- -->

<!-- Retrieve -->
<?php
error_reporting(1);
include("connection.php");
$sel = mysql_query("SELECT * FROM packages");
// echo "...";

while ($arr = mysql_fetch_array($sel)) {
    $pic = $arr['Picture'];
    // echo "";
}
?>

<!-- ----------------------------------------------------- -->

<!-- Retrieve -->
<?php
error_reporting(1);
include("connection.php");
$sel = mysql_query("SELECT * FROM packages WHERE Package='{$wlPkg}'");
// echo "...";

while ($arr = mysql_fetch_array($sel)) {
    $pic = $arr['Picture'];
    $pkg_name = $arr['Package'];
    $info = $arr['Info'];
    $id = $arr['ID'];
    $price = $arr['Price'];
    // echo "";
}
?>

<!-- ----------------------------------------------------- -->

<!-- Insert -->
<?php
error_reporting(1);
session_start();
include("connection.php");
$pkg_id = $_REQUEST['pkgID'];

if (isset($_POST['register_btn'])) {
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $pswd = $_POST['passwd'];
    $add = $_POST['addrs'];

    $sql = "INSERT INTO registers (ID, Name, Mobile, Email, Password, Address) VALUES('','$name','$mobile','$email','$pswd', '$add')";
    if (mysql_query($sql)) {
        //! IMPORTANT "php?Name=$name & Email=$email"
        $rp = "<font color='green' size='+1'> Registration Successful :) </font>";
        $_SESSION['sid'] = $email;
        header("location:packages_reg.php?Name=$name & Reply=$rp & eID=$email & pkgID=$pkg_id");
    } else {
        $rp = "<font color='red' size='+1'> Registration Failed :( </font>";
    }
}

if (isset($_POST['login_btn'])) {
    header("location:login.php?pkgID=$pkg_id");
}

?>

<!-- ----------------------------------------------------- -->

<!-- Retrieve preCheck -->

<?php
error_reporting(1);
include("connection.php");

$preCheck = mysql_query("SELECT * FROM feedback");
while ($row = mysql_fetch_object($preCheck)) {
    $anyMsg = $row->Message;
    // echo "pre= $pre<br>";
    if (empty($anyMsg)) {
        echo "anyMessage >> " . $anyMsg;
        break;
    }
}

if ($anyMsg == "") {
    echo "
          <div class='send-message'>
            <div class='container'>
                <div class='row'>
                    <div class='col-md-12'>
                        <div class='section-heading'>
                          <center>
                            <h2>Nothing to show :( </h2>
                          </center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
          ";
} else {
    echo "

    
      <div class='container'>
        <div class='col-md-12'>
            <table class='table'>
            <tr class='table-info'>
                <td class='col-md-2'>
                <h5>Name</h5>
                </td>
                <td class='col-md-2'>
                <h5>Gmail</h5>
                </td>
                <td class='col-md-2'>
                <h5>Mobile No.</h5>
                </td>
                <td class='col-md-6'>
                <center>
                    <h5>Message</h5>
                </center>
                </td>
            </tr>
        ";

    $sel = mysql_query("SELECT * FROM feedback");
    while ($arr = mysql_fetch_array($sel)) {
        $name = $arr['Name'];
        $mob = $arr['Mobile'];
        $email = $arr['Email'];
        $msg = $arr['Message'];

        echo "

            <tr class='table-secondary'>
                <td class='col-md-2'>
                <h6>$name</h6>
                </td>

                <td class='col-md-3'>
                <h6>$email</h6>

                </td>
                <td class='col-md-2'>
                <h6>$mob</h6>

                </td>
                <td class='col-md-5'>
                <h6>$msg</h6>
                </td>
            </tr>
                        ";
    }
    echo "</table>
        </div>
    </div>";
}
?>