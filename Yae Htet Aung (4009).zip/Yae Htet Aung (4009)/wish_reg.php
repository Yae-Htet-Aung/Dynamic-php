<!-- mpc -->
<?php
error_reporting(1);
session_start();
$rp = $_REQUEST["rp"];
$eId = $_REQUEST["eId"];
$pkgName = $_REQUEST["pName"];

include("connection.php");

if ($_SESSION['sid'] == "") {
  header('location:sry.html');
} else {
?>

  <!DOCTYPE html>
  <html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>Wish List</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--

TemplateMo 546 my Clothing

https://templatemo.com/tm-546-my-clothing

-->

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
    <link rel="stylesheet" href="assets/css/owl.css">

    <!-- add -->
    <!-- <script src="https://kit.fontawesome.com/91371d62e4.js" crossorigin="anonymous"></script> -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">

    <!-- yae -->
    <link rel="stylesheet" href="style.css">
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
      <div class="jumper">
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php">
            <h2>Traveler<em>Vibe</em></h2>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <!-- <li class="nav-item">
                <a class="nav-link" href="index_reg.php?eId = $eId">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li> -->
              <!-- mni -->
              <?php
              echo "
              <li class='nav-item'>
                <a href='index_reg.php?eId=$eId' class='nav-link'>Home</a>
                <span class='sr-only'>(current)</span>
              </li>

              <li class='nav-item'>
                <a href='packages_reg.php?eId=$eId' class='nav-link'>Packages</a>
                <span class='sr-only'>(current)</span>
              </li>

              <li class='nav-item'>
                <a href='contact_reg.php?eId=$eId' class='nav-link'>Contact Us</a>
                <span class='sr-only'>(current)</span>
              </li>

              <li class='nav-item active'>
                <a href='#' class='nav-link'>Wish List</a>
                <span class='sr-only'>(current)</span>
              </li>

              <li class='nav-item'>
                <a href='profile.php?eId=$eId' class='nav-link'>Profile</a>
                <span class='sr-only'>(current)</span>
              </li>
              ";
              ?>

              <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="banner header-text">
      <img src="pictures/register_heading.png" style="background-repeat: no-repeat; background-size: cover;" width="100%">
      <div class="text-content">
        <br><br><br>
        <h2>
          <em>
            <font class="myH1">Wish List</font>
          </em>
        </h2>
        <?php

        $d = mysql_query("SELECT * FROM registers WHERE Email='{$eId}' ");
        $row = mysql_fetch_object($d);
        $name = $row->Name;

        ?>
      </div>
    </div>
    <!-- Banner Ends Here -->

    <?php
    $preCheck = mysql_query("SELECT * FROM wish_list WHERE Email='{$eId}'");
    while ($row = mysql_fetch_object($preCheck)) {
      $anyPackage = $row->PackageName;
      // echo "pre= $pre<br>";
      if (empty($anyPackage)) {
        echo "anyPackage >> " . $anyPackage;
        break;
      }
    }

    if ($anyPackage == "") {
      echo "
          <div class='send-message'>
            <div class='container'>
                <div class='row'>
                  <div class='col-12'>
                      <div class='section-heading'>
                        <center>
                          <h2>Nothing to show :( </h2>
                        </center>
                      </div>
                  </div>
                </div>
            </div>
          </div>
          ";
    } else {
      echo "

      <div class='send-message col-12'>
        <div class='col-12'>
          <div class='section-heading mb-3'>
            <h4><font class='myRp'>$name</font>, this is your wish list. </h4>
            <h6><font color='myErr'> $pkgName </font> $rp </h6>
          </div>
        </div>

        <table class='table col-12'>
          <tr class='table-info'>
            <td class='col-3'>
              <h5>Package Name</h5>
            </td>
            <td class='col-4'>
              <h5>Details</h5>
            </td>
            <td class='col-2'>
              <h5>Price</h5>
            </td>
            <td class='col-3'>
            </td>
          </tr>";


      $wish_list = mysql_query("SELECT * FROM wish_list WHERE Email='{$eId}'");

      while ($arr = mysql_fetch_object($wish_list)) {
        $wlPkg = $arr->PackageName;
        // echo "$wlPkg";

        /// start Packages 
        $sel = mysql_query("SELECT * FROM packages WHERE Package='{$wlPkg}'");
        while ($arr = mysql_fetch_array($sel)) {
          $pic = $arr['Picture'];
          $pkgName = $arr['Package'];
          $info = $arr['Info'];
          $id = $arr['ID'];
          $price = $arr['Price'];

          echo "

          <tr class='col-12 table-secondary'>
            <td class='col-3'>
              <h6><i>$pkgName</i></h6>
              <h6>$id</h6>
            </td>
            <td class='col-4'>
              <h6>$info</h6>
            </td>
            <td class='col-2'>
              <h6>$price</h6>
            </td>
            <td class='col-3 justify-content-md-center'>
              <div class='col-md-auto '>
                <a href='wish_remove.php?pName=$pkgName&eId=$eId' class='filled-button'>Remove</a>
                <a href='booking_create.php?pId=$id&eId=$eId' class='filled-button'>Book Now</a>
              </div>
            </td>
          </tr>
                        ";
        } /// packages


      } /// wish

      echo "</table>
    </div>";
    }
    ?>

        <footer>
          <?php
          if ($anyPackage == "") {
            echo "<h4><font class='myErr'>Add any packages by clicking the heart icon.</font></h4>";
          } else {
            echo "
      <div class='container'>
        <div class='row'>
          <div class='col-12'>
            <a class='filled-button' href='#'>Go to top</a>
          </div>
        </div>
      </div>
      ";
          }
          ?>


          <div class="container">
            <div class="row">
              <div class="col-12">
                <div class="inner-content">
                  <p>Copyright &copy; 2020 TravelerVibe.com.

                    - Design: <a rel="nofollow noopener" href="https://templatemo.com" target="_blank">TemplateMo</a></p>
                </div>
              </div>
            </div>
          </div>

        </footer>


        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Additional Scripts -->
        <script src="assets/js/custom.js"></script>
        <script src="assets/js/owl.js"></script>
        <script src="assets/js/slick.js"></script>
        <script src="assets/js/isotope.js"></script>
        <script src="assets/js/accordions.js"></script>

        <script language="text/Javascript">
          cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
          function clearField(t) { //declaring the array outside of the
            if (!cleared[t.id]) { // function makes it static and global
              cleared[t.id] = 1; // you could use true and false, but that's more typing
              t.value = ''; // with more chance of typos
              t.style.color = '#fff';
            }
          }
        </script>

  </body>

  </html>

<?php } ?>